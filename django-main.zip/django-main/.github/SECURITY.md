# Django Security Policies

Please see https://www.djangoproject.com/security/.
